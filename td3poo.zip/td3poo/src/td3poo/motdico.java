package td3poo;

public class motdico {
private static int compteur=1;
private int num;
private String mot;
private String definition;

public motdico(String mot,String definition) {
	this.num=compteur++;
	this.mot=mot;
	this.definition=definition;
}

public String getmot() {
	return mot;
}
public String getdefinition() {
	return definition;
}
public void setdefinition(String s) {
	this.definition=s;
}
public void setmot(String s) {
	this.mot=s;}

public boolean synonyme(motdico m) {
	if(m.mot == this.mot && m.definition == this.definition) {
		return true;
	}
	else {
		return false;
	}
}
}
