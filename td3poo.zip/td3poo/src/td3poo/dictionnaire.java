package td3poo;

public class dictionnaire {
private int nbmots;
private motdico[] dico;
private String nom;

public dictionnaire(String nom,int t) {
	this.nom=nom;
	this.nbmots=0;
	this.dico= new motdico[t];
}
public void ajoutermot(motdico m) {
	dico[nbmots]=m;
	nbmots++;
}
public void supprimermot(String ch) {
	int i;
	int v=chercher(ch);
	if (v!=-1){
		for(i=v;i<nbmots;i++) {
			dico[i]=dico[i+1];
		}
		dico[nbmots-1]=null;
	}
	else {
		System.out.println("mot pas trouve");
	}
}

public int chercher(String s) {
	int i;
	for(i=0;i<nbmots;i++) {
		if(dico[i].getmot()==s) {
			return i;
		}
	}
	return -1;
}





}
