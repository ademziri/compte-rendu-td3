package td3poo;

public class maindico {

	public static void main(String[] args) {
	dictionnaire larousse= new dictionnaire("larousse",10);
	

	}

}
